const express = require('express');
const ADODB = require('node-adodb');
const bodyParser = require('body-parser');
//var todoRouter = require('./todoRouter');
const server = express();
const PORT = 8000;

var connection = ADODB.open('Provider=Microsoft.ACE.OLEDB.12.0;Data Source=IBPSDatabase.accdb;Persist Security Info=False;');

process.env.DEBUG = 'ADODB';

console.log(JSON.stringify(connection))
server.use(bodyParser.urlencoded({ extended: true }));
server.use(bodyParser.json());
server.use(function(req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    next();
});

server.post('/add', function(req, res) {
    console.log("got call")
    var data = req.body
    console.log(JSON.stringify(data))

    if (data) {
        //console.log(JSON.stringify(data))

        var dataString = '"' + data.question + '","' + data.optionA + '","' + data.optionB + '","' + data.optionC + '","' + data.optionD + '","' + data.answer + '","' + data.explaination + '"';
        //console.log(dataString);
        connection
            .execute('INSERT INTO aptitude(question, optionA, optionB, optionC, optionD, answer, explaination) VALUES (' + dataString + ')')
            .on('done', function(data) {
                console.log('Result:', JSON.stringify(data, null, '  '));
            })
            .on('fail', function(data) {
                console.log("filed " + JSON.stringify(data))
            });

    }
})

server.get('/', function(req, res) {
    res.send('Hello World');
});

//server.use('/todo', todoRouter);

server.listen(PORT);
console.log('listening on port ' + PORT);
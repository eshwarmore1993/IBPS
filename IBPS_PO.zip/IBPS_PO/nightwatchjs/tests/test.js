module.exports = {


    'step one': function(browser) {

            function AddRecord(question, a, b, c, d, answer, explain) {

                var record1 = {
                    "question": question,
                    "optionA": a,
                    "optionB": b,
                    "optionC": c,
                    "optionD": d,
                    "answer": answer,
                    "explaination": explain
                };

                var records = [record1]
                    //console.log(JSON.stringify(record1))
                browser.execute(function(record1) {
                    console.log("data ->> " + JSON.stringify(record1))
                    $.ajax({
                        type: "POST",
                        url: "http://127.0.0.1:8000/add",
                        headers: { 'Access-Control-Allow-Origin': '*' },
                        //contentType: "application/json",
                        data: record1,
                        success: processSuccess,
                        error: processError
                    });

                    function processSuccess(data, status, req) {
                        console.log(JSON.stringify(status))
                    }

                    function processError(data, status, req) {
                        console.log(JSON.stringify(status))
                    }
                }, records);

                //var myDB = new ACCESSdb("E:\IBPS_PO\IBPSDatabase.accdb");

                //var SQL = "INSERT INTO aptitude VALUES('" + question + "','" + a + "','" + b + "','" + c + "','" + d + "','" + answer + "','" + explain + "')";
                //if (myDB.query(SQL)) {
                //    console.log("Inserted!");
                //} else {
                //    console.log("failed");
                //}
                //adoConn.Open("Provider=Microsoft.Jet.OLEDB.4.0;Data Source='E:\IBPS_PO\IBPSDatabase.accdb'");
                //adoRS.Open("Select * From aptitude", adoConn, 1, 3);

                // adoRS.AddNew;
                // adoRS.Fields("question").value = question;
                // adoRS.Fields("optionA").value = a;
                // adoRS.Fields("optionB").value = b;
                // adoRS.Fields("optionC").value = c;
                // adoRS.Fields("optionD").value = d;
                // adoRS.Fields("answer").value = answer;
                // adoRS.Fields("explaination").value = explain;


                // adoRS.Update;

                // adoRS.Close();
                // adoConn.Close();
            }

            for (var index = 1; index <= 214; index++) {
                browser
                    .url('http://www.onlinetest.ibpsexamguru.in/questions/PO-Quantitative-Aptitude/Q-Test-No-' + index)
                    .injectScript('E:\IBPS_PO\nightwatchjs\tests\accessdb.js')
                    //.waitForElementVisible('body', 1000)
                    .useXpath()
                for (var tno = 1; tno <= 10; tno++) {
                    var q = "",
                        a = "",
                        b = "",
                        c = "",
                        d = "",
                        ans = "",
                        exp = "";
                    browser.getText("/html/body/table/tbody/tr/td[2]/table/tbody/tr[3]/td/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[" + tno + "]/tbody/tr[1]", function(result) {
                        q = result.value
                            //console.log(q)
                    });

                    //options
                    browser.getText('//*[@id="ans_' + tno + '' + tno + '1"]', function(result) {
                        a = result.value
                    });

                    browser.getText('//*[@id="ans_' + tno + '' + tno + '2"]', function(result) {
                        b = result.value
                    });

                    browser.getText('//*[@id="ans_' + tno + '' + tno + '3"]', function(result) {
                        c = result.value
                    });

                    browser.getText('//*[@id="ans_' + tno + '' + tno + '4"]', function(result) {
                        d = result.value
                    });

                    //answer
                    browser.click('/html/body/table/tbody/tr/td[2]/table/tbody/tr[3]/td/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[' + tno + ']/tbody/tr[6]/td/table/tbody/tr/td[1]/a')
                    browser.getText('//*[@id="wiewans_' + tno + '"]/div[2]/table/tbody/tr[1]/td', function(result) {
                        ans = result.value
                    });

                    //explaination
                    //browser.click('/html/body/table/tbody/tr/td[2]/table/tbody/tr[3]/td/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td/table[' + tno + ']/tbody/tr[6]/td/table/tbody/tr/td[1]/a')
                    browser.getText('//*[@id="wiewans_' + tno + '"]/div[2]/table/tbody/tr[5]', function(result) {
                        exp = result.value

                        AddRecord(q, a, b, c, d, ans, exp)
                    });

                }
            }
            browser.end()
        }
        // },

    // elements: {
    //     td: {
    //         selector: '/html/body/table/tbody/tr/td[2]/table/tbody/tr[3]/td/div/table/tbody/tr/td[2]/table/tbody/tr[4]/td',
    //         locateStrategy: 'xpath'
    //     }
    // }
};